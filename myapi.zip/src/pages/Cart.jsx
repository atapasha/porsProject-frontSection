
import '../styles/Cart.css'


const Cart = (props) => {


    const { cartItems, onAdd, onRemove } = props;
    console.log(cartItems)
    const totalPrice = cartItems.reduce((price, item) => price + item.qty * item.price, 0)



    return (
        <aside className="main">
            <div className='row'>
                <div><h1>
                    sabad
                </h1>
                </div>
                {cartItems.map((item) => (

                    <div key={item.id} className="row itemclass">

                        <div className='col-2'>{item.name}
                            <img className='imgcart' src={item.image01} alt="ds" /></div>
                        <div className='col-2  '>
                            <button className='greebbtn' onClick={() => onAdd(item)}>+  </button>
                            <button className='redbtn' onClick={() => onRemove(item)}>-  </button>
                        </div>
                        < div className='col-2  text-right payment' > {item.qty} * ${item.price?.toFixed(2)}

                        </div>
                    </div >

                ))
                }

                <div>
                    {cartItems.length === 0 && <div>cart is empty</div>}

                </div>
            </div>


            {
                cartItems.length !== 0 && (
                    <>
                        <hr></hr>Total price
                        <div className='cartItem'>
                            <div>${totalPrice}</div>
                        </div>
                    </>
                )
            }
        </aside >

    )



    // return (
    //     <>
    //         <div cartItem='cart-items'>
    //             <div className='cart-items-header'>

    //                 {cartItem.length === 0 && (<div>no cart items</div>)}

    //                 <div>
    //                     {cartItem.map((item) => (
    //                         <div key={item.id}>
    //                             <img width="40px" src={item.image} alt={item.name} />
    //                             <div>{item.name}</div>
    //                             {/* <div><button onClick={() => handleAddProduct(item)}>+</button></div>
    //                             <div><button onClick={() => handleRemoveroduct(item)}>-</button></div> */}
    //                             <div>{item.quantity}*{item.price}</div>


    //                         </div>
    //                     ))}
    //                 </div>
    //             </div>
    //         </div>

    //     </>)


}

export default Cart 