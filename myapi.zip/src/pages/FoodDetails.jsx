import React from 'react'

const FoodDetails = () => {
    return (
        <div>FoodDetails</div>
    )
}

export default FoodDetails