import React from 'react'
import page404 from '../assets/images/page404.jpg'
const NotFound = () => {
    return (
        <div>

            <img alt="sa" src={page404} />
        </div>
    )
}

export default NotFound