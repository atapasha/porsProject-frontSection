import React from 'react'

const AllFoods = () => {
    return (
        <div>AllFoods</div>
    )
}

export default AllFoods