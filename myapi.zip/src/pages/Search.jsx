import React from 'react'
import '../styles/search.css'
const Search = () => {
    return (
        <div className=' font-2 '>
            <input type="text" className="search-hover" placeholder="Search Food..." />

        </div>)
}

export default Search