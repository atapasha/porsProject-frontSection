import React from 'react'
import productImg from '../../../assets/images/product1.jpg'
import { Link } from "react-router-dom"
import '../../../styles/product-card.css';
import { useDispatch } from 'react-redux';
import Cart from '../../../pages/Cart';
import cartActions from '../../../store/shopping-cart/cartSlice';
import products from '../../../assets/fake-data/products';
const ProductCard = (props) => {

    const { product, onAdd } = props

    console.log(product)
    // const dispatch = useDispatch()

    // const addToCart = () => {
    //     console.log()
    //     dispatch(cartActions.addItem({
    //         id,
    //         title,
    //         image01,
    //         price

    //     }));
    // }

    return (
        <>


            < div key={product.id} className='product__item' style={{ marginButton: "10px" }}>

                < div className="product__img" >
                    <img src={product.image01} alt="product-img" className='w-100' />
                </div >


                < div className="product__content" >
                    <h5><Link to={`/foods/${product.id}`}>{product.title}</Link></h5>
                    <div className='d-flex align-items-center justify-content-between '>
                        <span className='product__price'>{product.price}</span>
                    </div>
                    <button className="addToCart__btn" onClick={() => onAdd(product)}>Add to Cart</button>
                </div >


            </div >







        </>
    )


}

export default ProductCard