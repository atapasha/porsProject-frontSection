import React from 'react'
import "../../styles/footer.css"
const Footer = () => {
    return (
        <div className='Footer'>
            <div className="Footer1 text-white">
                <h4>text</h4>
                <h4>text</h4>
                <h4>text</h4>
                <h4>text</h4>
                <h4>text</h4>
                <h4>text</h4>
                <h4>text</h4>
            </div>
            <div className="Footer2">2</div>
            <div className="Footer3">3</div>

        </div>
    )
}

export default Footer